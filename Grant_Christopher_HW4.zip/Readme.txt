CS 1571 Homework 4 Programming Assignment 

By Christopher Grant

This project is written in Python 3.6.2, but should run under any version of python 3.

The only additional library needed to run this code is the csv library, which is included in the default python libraries.

Everything in this project works. 

There are points where I've rounded the output of the program for the sake of readability. This can be undone by deleting the contents between any {} within a print statement. 